PUTIN AT WAR AGAINST UKRAINE - THE WORLD AT WAR AGAINST PUTIN

On February 24, 2022, Ukraine is invaded by Russia by order of the President
Russian Vladimir Putin.

That's a madman getting herself for Hitler, bursting a region and can rock
The world, our world, in the Third World War.

The European Union is not perfect, but it has helped keep peace on the
old continent for 75 years.

If you think your freedom is important,
if you think we can stop a war without pouring blood,
if you prefer to bequeath your children a world of peace rather than ruins,
participate in the fight using the joint scripts.

The Russian people, so brave and honorable, does not deserve such a dictator:
Help him to revolt by fighting against misinformation.

брусничн


ABOUT THESE SCRIPTS
-------------------

Joint scripts (All.bat for Windows, All.sh for Linux) contact several
Russian sites to participate in a denial of service (the target server
becomes inaccessible due to too much large number of requests).

Even if a server refuses the connection, it must process the request.
This means can seem ridiculous, but it becomes redoutably effective if
thousands of people put it into practice.

Scripts do not require any installation and download nothing.
They ask very few resources and no disk space.
Their network consumption is weak.

Other scripts focus on a single site: Itar-Tass, Kremlin, Mospravda, Pravda,
RT, SputnikNews, Tass. You can run them separately and as many times as you
want. This allows you to choose the targets and the strength of the attack.

Improve these scripts, translate them, run them, disseminate them!

Lingonberry
